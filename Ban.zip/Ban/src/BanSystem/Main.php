<?php

namespace BanSystem;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\Server;
use jojoe77777\FormAPI\CustomForm;

class Main extends PluginBase implements Listener {

    private Config $banData;
    private Config $warnData;

    // Genişletilmiş küfür listesi
    private array $bannedWords = [
        "amk", "amq", "amcık", "amına", "siktir", "sikiyim", "sikmek", "orospu", "piç", "oç",
        "ananı", "aq", "yarak", "göt", "sikiş", "pezevenk", "ibne", "mal", "salak", "aptal",
        "gerizekalı", "şerefsiz", "gavat", "gavur", "çük", "sex", "seks", "sik"
    ];

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->banData = new Config($this->getDataFolder() . "bans.yml", Config::YAML);
        $this->warnData = new Config($this->getDataFolder() . "warns.yml", Config::YAML);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("BanSystem ve Küfür Filtresi aktif.");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch ($command->getName()) {
            case "banla":
                if ($sender instanceof Player) {
                    $this->showBanForm($sender);
                } else {
                    $sender->sendMessage("Sadece oyuncular kullanabilir.");
                }
                return true;

            case "banac":
                if ($sender instanceof Player) {
                    $this->showUnbanForm($sender);
                } else {
                    $sender->sendMessage("Sadece oyuncular kullanabilir.");
                }
                return true;
        }
        return false;
    }

    public function showBanForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) return;

            [$target, $days, $reason] = $data;

            if (empty($target) || empty($reason)) {
                $player->sendMessage("§cTüm alanlar doldurulmalı.");
                return;
            }

            $until = strtolower($days) === "sınırsız" ? "perm" : time() + ((int)$days * 86400);
            $this->banData->set(strtolower($target), [
                "until" => $until,
                "reason" => $reason,
                "banned_by" => $player->getName()
            ]);
            $this->banData->save();

            $player->sendMessage("§a{$target} başarıyla banlandı.");
            $targetPlayer = Server::getInstance()->getPlayerExact($target);
            if ($targetPlayer !== null) {
                $targetPlayer->kick("§cBanlandınız!\nSebep: $reason");
            }
        });

        $form->setTitle("Oyuncu Banla");
        $form->addInput("Banlanacak oyuncu ismi:");
        $form->addInput("Kaç gün? (Kalıcı için: sınırsız):");
        $form->addInput("Sebep:");
        $player->sendForm($form);
    }

    public function showUnbanForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) return;

            $target = strtolower(trim($data[0]));
            if ($this->banData->exists($target)) {
                $this->banData->remove($target);
                $this->banData->save();
                $player->sendMessage("§a{$target} adlı oyuncunun banı açıldı.");
            } else {
                $player->sendMessage("§c{$target} adlı oyuncu banlı değil.");
            }
        });

        $form->setTitle("Ban Aç");
        $form->addInput("Banı açılacak oyuncunun ismi:");
        $player->sendForm($form);
    }

    public function isBanned(string $name): bool {
        $entry = $this->banData->get(strtolower($name));
        if ($entry === null) return false;

        if ($entry["until"] === "perm") return true;

        return time() < (int)$entry["until"];
    }

    public function getBanReason(string $name): ?string {
        $entry = $this->banData->get(strtolower($name));
        return $entry["reason"] ?? null;
    }

    public function onPlayerLogin(PlayerLoginEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $entry = $this->banData->get($name);

        if (!is_array($entry)) return;

        if (($entry["until"] ?? null) === "perm") {
            $event->setKickMessage("§cSunucudan kalıcı olarak banlandınız!\nSebep: {$entry["reason"]}");
            $event->cancel();
        } elseif (time() < (int)($entry["until"] ?? 0)) {
            $remaining = (int)$entry["until"] - time();
            $days = floor($remaining / 86400);
            $hours = floor(($remaining % 86400) / 3600);
            $minutes = floor(($remaining % 3600) / 60);

            $msg = "§cSunucudan geçici olarak banlandınız!\n";
            $msg .= "Sebep: {$entry["reason"]}\n";
            $msg .= "Kalan süre: {$days}g {$hours}s {$minutes}dk";

            $event->setKickMessage($msg);
            $event->cancel();
        }
    }

    // Mesajı sadece harf ve rakamlardan oluşacak şekilde temizle
    private function sanitizeMessage(string $message): string {
        return preg_replace("/[^a-z0-9]/", "", strtolower($message));
    }

    public function onPlayerChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $this->sanitizeMessage($event->getMessage());
        $name = strtolower($player->getName());

        foreach ($this->bannedWords as $word) {
            if (strpos($message, $word) !== false) {
                $warnCount = $this->warnData->get($name, 0);

                if ($warnCount === 0) {
                    // 1. uyarı
                    $player->sendMessage("§cUYARI: Küfür yasak! Bir daha yaparsanız ceza alırsınız.");
                    $this->warnData->set($name, 1);
                    $this->warnData->save();
                } elseif ($warnCount === 1) {
                    // 2. kick
                    $player->kick("§cKüfür ettiğiniz için sunucudan atıldınız! Bir daha yapmayın.");
                    $this->warnData->set($name, 2);
                    $this->warnData->save();
                } elseif ($warnCount >= 2) {
                    // 3. 2 günlük ban
                    $banUntil = time() + (2 * 86400);
                    $this->banData->set($name, [
                        "until" => $banUntil,
                        "reason" => "Küfür nedeniyle otomatik ban",
                        "banned_by" => "Otomatik Sistem"
                    ]);
                    $this->banData->save();
                    $player->kick("§cKüfür ettiğiniz için 2 gün banlandınız!");
                    $this->warnData->remove($name);
                    $this->warnData->save();
                }

                $event->cancel();
                return;
            }
        }
    }
}